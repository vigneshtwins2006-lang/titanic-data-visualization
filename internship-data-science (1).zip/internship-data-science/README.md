# InternCircle Data Science Internship: Tasks 0-2

**Author:** Vignesh Murugesan

| # | Task | Deliverable |
|---|------|-------------|
| 0 | Share Offer Letter and Data Lab Setup | `00_Data_Lab_Setup.ipynb`, `linkedin_post.md` |
| 1 | Exploratory Data Analysis on Titanic | `01_Titanic_EDA.ipynb` |
| 2 | Data Visualization with Matplotlib and Seaborn | `02_Data_Visualization.ipynb`, `figures/` |

## Task 1: EDA highlights
- Loaded the Titanic dataset (891 passengers, 12 columns) and inspected it with `head`, `info`, `describe`
- Handled missing values: Age (group-median imputation by class and sex), Embarked (mode), Cabin (converted to a `HasCabin` flag)
- Checked duplicates, engineered Title, FamilySize, IsAlone and AgeGroup
- Grouping and aggregation: survival by sex, class, age group, port, family size and title
- Key result: 38.4% survived; 74% of women vs 19% of men; 63% of 1st class vs 24% of 3rd class

## Task 2: Visualization highlights
Bar charts, count plots, histograms (with KDE), box plots, violin plot, scatter and regression plots, correlation heatmap, pivot heatmap and a 4-panel dashboard, with custom colour palettes and formatted axes. All images are in [`figures/`](figures/).

![Dashboard](figures/10_dashboard.png)

## Run it
Open any notebook in **Google Colab** (File > Upload notebook) and choose *Runtime > Run all*. The notebooks download the dataset automatically.

Local:
```bash
pip install -r requirements.txt
jupyter notebook
```

## Data
Titanic passenger dataset (public, widely used for learning). Raw and cleaned copies are in `data/`.
